﻿
#year-month-day
param([string] $LastImportDate)
$SISDate=$LastImportDate

$drugproduct= Invoke-RestMethod -uri "https://health-products.canada.ca/api/drug/drugproduct/?lang=en&type=json"
$company= Invoke-RestMethod -uri "https://health-products.canada.ca/api/drug/company/?lang=en&type=json"
$veterinaryspecies=Invoke-RestMethod -uri "https://health-products.canada.ca/api/drug/veterinaryspecies/?lang=en&type=json"
$packaging=Invoke-RestMethod -uri "https://health-products.canada.ca/api/drug/packaging/?type=json"
$approvestatus= Invoke-RestMethod -uri "https://health-products.canada.ca/api/drug/drugproduct/?status=1&lang=en&type=json"
$cancelstatus= Invoke-RestMethod -uri "https://health-products.canada.ca/api/drug/drugproduct/?status=3&lang=en&type=json"


$drugproduct |  Where-Object last_update_date -ge $SISDate |export-csv "C:\SSIS_FinalProject\drugproduct.csv" -NoTypeInformation
$company     |export-csv "C:\SSIS_FinalProject\company.csv" -NoTypeInformation
$veterinaryspecies |export-csv "C:\SSIS_FinalProject\veterinaryspecies.csv" -NoTypeInformation
$packaging  |export-csv "C:\SSIS_FinalProject\packaging.csv" -NoTypeInformation
$approvestatus | export-csv "C:\SSIS_FinalProject\approvestatus.csv" -NoTypeInformation
$cancelstatus | export-csv "C:\SSIS_FinalProject\cancelstatus.csv" -NoTypeInformation

