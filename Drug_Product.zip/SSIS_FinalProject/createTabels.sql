CREATE DATABASE Drug_Status_Database;
go
use  Drug_Status_Database;



CREATE TABLE [dbo].[approvestatus](
	[drug_code] [bigint]  NOT NULL,
	[class_name] [varchar](40) NOT NULL,
	[drug_identification_number] [varchar](29) NOT NULL,
	[brand_name] [varchar](200) NOT NULL,
	[descriptor] [varchar](150) NULL,
	[number_of_ais] [varchar](10) NOT NULL,
	[ai_group_no] [varchar](10) NOT NULL,
	[company_name] [varchar](80) NOT NULL,
	[last_update_date] [date] NOT NULL
)


CREATE TABLE [dbo].[cancelstatus](
	[drug_code] [bigint]  NOT NULL,
	[class_name] [varchar](40) NOT NULL,
	[drug_identification_number] [varchar](29) NOT NULL,
	[brand_name] [varchar](200) NOT NULL,
	[descriptor] [varchar](150) NULL,
	[number_of_ais] [varchar](10) NOT NULL,
	[ai_group_no] [varchar](10) NOT NULL,
	[company_name] [varchar](80) NOT NULL,
	[last_update_date] [date] NOT NULL
)

CREATE TABLE [dbo].[company](
	[city_name] [varchar](60) NOT NULL,
	[company_code] [bigint] NOT NULL,
	[company_name] [varchar](80) primary key NOT NULL,
	[company_type] [varchar](40) NOT NULL,
	[country_name] [varchar](40) NOT NULL,
	[post_office_box] [varchar](15) NULL,
	[postal_code] [varchar](20) NULL,
	[province_name] [varchar](40) NOT NULL,
	[street_name] [varchar](80) NULL,
	[suite_number] [varchar](20) NULL,
	)


	CREATE TABLE [dbo].[drugproduct](
	[drug_code] [bigint] primary key NOT NULL,
	[class_name] [varchar](40) NOT NULL,
	[drug_identification_number] [varchar](29) NOT NULL,
	[brand_name] [varchar](200) NOT NULL,
	[descriptor] [varchar](150) NULL,
	[number_of_ais] [varchar](10) NOT NULL,
	[ai_group_no] [varchar](10) NOT NULL,
	[company_name] [varchar](80) NOT NULL,
	[last_update_date] [date] NOT NULL,
	)
	CREATE TABLE [dbo].[packaging](
	[drug_code] [bigint] primary key NOT NULL,
	[upc] [varchar](12) NULL,
	[package_size_unit] [varchar](40) NULL,
	[package_type] [varchar](40) NULL,
	[package_size] [varchar](5) NULL,
	[product_information] [varchar](80) NULL,
	)
	CREATE TABLE [dbo].[veterinaryspecies](
	[drug_code] [bigint] NOT NULL,
	[vet_species_name] [varchar](160) NOT NULL
)


ALTER TABLE [dbo].[approvestatus]
ADD FOREIGN KEY ([drug_code])
REFERENCES [dbo].[drugproduct]([drug_code] );

ALTER TABLE [dbo].[cancelstatus]
ADD FOREIGN KEY ([drug_code])
REFERENCES [dbo].[drugproduct]([drug_code] );

ALTER TABLE [dbo].[packaging]
ADD FOREIGN KEY ([drug_code])
REFERENCES [dbo].[drugproduct]([drug_code] );


ALTER TABLE [dbo].[veterinaryspecies]
ADD FOREIGN KEY ([drug_code])
REFERENCES [dbo].[drugproduct]([drug_code] );

ALTER TABLE [dbo].[drugproduct]
ADD FOREIGN KEY ([company_name])
REFERENCES [dbo].[company]([company_name]);
