

--Mary question: Identify all approved drug from drug product by approved status table from LONZA LLC company.

select drugProduct.[drug_code],drugProduct.[brand_name], drugProduct.[descriptor] from [dbo].[drugproduct] as drugProduct
inner join [dbo].[approvestatus] as approved
on approved.[drug_code] = drugProduct.[drug_code]
where drugProduct.company_name='LONZA LLC'


--Kandi question: What are the products that have been canceled before they were ever marketed? please include the product drug code, class name, brand name, and company name.
select drugProduct.[drug_code],drugProduct.[brand_name] ,drugProduct.[class_name] , drugProduct.company_name from [dbo].[drugproduct] as drugProduct
inner join [dbo].[cancelstatus] AS canceled
on canceled.[drug_code] = drugProduct.[drug_code]


--Tan question: Identify brand name and company name offers drugs that are being used for Dog and packed as Tablet.
select  drugProduct.[drug_code], [dbo].[drugproduct].[brand_name], company.[company_name], 
veterinaryspecies.vet_species_name, packaging.package_size_unit
from [dbo].[drugproduct] 
inner join company on company.company_name = drugproduct.company_name
left join [dbo].[veterinaryspecies] on veterinaryspecies.[drug_code]=drugProduct.[drug_code]
left join packaging on packaging.drug_code = drugproduct.drug_code
where veterinaryspecies.[vet_species_name]= 'Dogs' and packaging.package_size_unit = 'tablet'
order by drugproduct.drug_code;

 
-- Jin question: List out all drug_code for human use that are approved. 
select [dbo].[drugproduct].drug_code, [dbo].[drugproduct].brand_name, [dbo].[drugproduct].class_name
from [dbo].[drugproduct]
inner join approvestatus
on [dbo].[approvestatus].drug_code = [dbo].[drugproduct].drug_code
where [dbo].[drugproduct].class_name = 'Human'