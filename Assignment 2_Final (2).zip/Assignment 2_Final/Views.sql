
--Author: Mary Bello
--Assignment 2
--Create views
CREATE VIEW vwCases_per10000
AS
select max(c.cumulative_cases/p.population*10000) as rel_prop_cases_per10000,c.province 
from Cases as c
inner join [dbo].[Province_Population] as p
on p.Province =c.province
group by c.province



--Create Summary View
CREATE VIEW vwSummary
as
Select M,Y,lastDt, max([cumulative_cases]) as Cases, Max([cumulative_deaths]) as Deaths, Max([cumulative_recovered]) as Recovered from (
select MONTH(cast([date_active] as date)) M, 
Year(cast([date_active] as date)) Y,
FORMAT(Cast([date_active]as date),'MMM-yyyy') as lastDt,[cumulative_cases],[cumulative_deaths],[cumulative_recovered]
from Summary) as x
group by M, lastDt, Y


--Create Mortality view
CREATE VIEW vwMortality_per10000
as
select max(c.cumulative_deaths/p.population*10000) as rel_prop_death_per10000, c.province 
from MortalitY as c
inner join [dbo].[Province_Population] as p
on p.Province =c.province
group by c.province

--Create Vaccines
CREATE VIEW vwVaccines_per10000
as
select max(c.[cumulative_cvaccine]/p.population*10000) as cvaccines_per10000, c.province 
from Vaccines as c
inner join [dbo].[Province_Population] as p
on p.Province =c.province
group by c.province